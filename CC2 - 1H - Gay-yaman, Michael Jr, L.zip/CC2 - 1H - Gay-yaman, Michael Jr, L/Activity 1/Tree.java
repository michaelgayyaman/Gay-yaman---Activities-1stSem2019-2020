public class Tree{
public static void main(String[] args){
    System.out.println("   X");
    System.out.println("  XXX");
    System.out.println(" XXXXX");
    System.out.println("XXXXXXX");
    System.out.println("   X");
  }
}