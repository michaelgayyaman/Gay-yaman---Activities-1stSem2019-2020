public class Initial{
public static void main(String[] args){

    /*System.out.println("     M  GGGGGG");
    System.out.println("     M  G");
    System.out.println("     M  GGGG");
    System.out.println("M    M  G");
    System.out.println("MMMMMM  G");*/
    
    
    System.out.println("M          M  G G G G G G");
    System.out.println("M M      M M  G          ");
    System.out.println("M  M    M  M  G     G G G");
    System.out.println("M   M  M   M  G         G");
    System.out.println("M     M    M  G G G G G G");
    
  }
}