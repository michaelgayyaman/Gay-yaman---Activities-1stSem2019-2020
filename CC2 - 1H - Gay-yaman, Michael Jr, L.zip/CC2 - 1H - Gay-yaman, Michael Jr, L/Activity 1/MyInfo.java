public class MyInfo{
public static void main(String[] args){
    System.out.println("");
    System.out.println("Name:       Gay-yaman, Michael Jr, L");
    System.out.println("Course:     BSIT");
    System.out.println("Year:       1");
    System.out.println("Address:    BLV Bakakeng Central Baguio City");
    System.out.println("Adjective:  Taraki");
  }
}